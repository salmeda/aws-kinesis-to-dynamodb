import boto3
import base64
import json

print('Loading function')


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))
    
    dynamodb = boto3.resource('dynamodb') 
    #table name 
    table = dynamodb.Table('kinesis-to-dynamodb-ddb') 
    #inserting values into table 

    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        print("Decoded payload: " + payload)
        
        response = table.put_item(payload)
        
        print(str(response))
        
    return 'Successfully processed {} records.'.format(len(event['Records']))
    
    